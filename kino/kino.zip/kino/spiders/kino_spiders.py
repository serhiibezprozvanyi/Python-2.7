#-* coding:utf-8 -*-

from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors.sgml import SgmlLinkExtractor
from scrapy.contrib.loader.processor import TakeFirst
from scrapy.loader import XPathItemLoader
from scrapy.selector import HtmlXPathSelector
from kino.items import KinoItem



class KinoLoader(XPathItemLoader):
	default_output_processor = TakeFirst()

class KinoSpider(CrawlSpider):
	name = "kino"
	allowed_domains = ["my-hit.org"]
	start_urls = ["https://my-hit.org/"]
	rules = (
		Rule(SgmlLinkExtractor(allow=('/film/?p=[0-9]+')), follow=True),
		Rule(SgmlLinkExtractor(allow=('/film[0-9]+')), callback='parse_item'),
		)



def parse_item(self, response):
		hxs = HtmlXPathSelector(response)
		l = KinoLoader(KinoItem(), hxs)
		
		l.add_xpath('name', '//h1/text()')[0], l.add.xpath('//h1/a/text()')
		l.add_xpath('name_ang', '//h4/text()')
		l.add_xpath('dlina', '//div[@class="col-xs-10 col-md-8"]/ul[@class="list-unstyled"]/li/text()')[0]
		l.add_xpath('genre', '//div[@class="col-xs-10 col-md-8"]/ul[@class="list-unstyled"]/li/a/text()')[0]
		l.add_xpath('strana', '//div[@class="col-xs-10 col-md-8"]/ul[@class="list-unstyled"]/li[3]/a/text()')
		l.add_xpath('slogan', '//div[@class="col-xs-10 col-md-8"]/ul[@class="list-unstyled"]/li[4]/text()')
		return l.load_item()
		
		